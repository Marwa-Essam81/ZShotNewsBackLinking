import numpy as np
from segtok.segmenter import split_single
import pymysql
from sklearn.metrics.pairwise import cosine_similarity


def loadQueryParagraphEncodings(qIds, QueryDir,CLS=True):
    QParaEncodings = {}
    for query in qIds.keys():
        QPNO = 1
        QParagrapgs = {}
        fq = open(QueryDir + "/" + query, encoding='utf-8')
        content = ""
        for line in fq:
            content = content + line
        paragraphs = content.split("<Paragraph>")
        for p in paragraphs:
            if (len(p.strip()) == 0):
                continue
            pcontent=p.replace("<pooled>","<Pooled>").split("<Pooled>")
            #print(p)
            if(CLS):
                p=pcontent[0].strip()
            else:
                p = pcontent[1].strip()
            qEncoding = []
            data = p.strip().split(" ")
            for d in data:
                qEncoding.append(np.float32(d))
            QParagrapgs[QPNO] = qEncoding
            QPNO = QPNO + 1
        QParaEncodings[query] = QParagrapgs
    print("loaded paragraph vectors for : ", len(QParaEncodings.keys()), " Queries")
    return QParaEncodings

# the following method scores candidate articles against the query passages (generated from sliding a window over paragraphs)
def getDocumentScoreFromQueryParaSlided(QParagrapgs, DocEncoding, maxFlag, window):
    MaxScore = 0.0
    SumScore = 0.0
    content = ""
    paraScores = {}
    count = 1
    toggle = False
    chunk=0
    while (toggle == False):
        start = count
        end = count + window
        if (end >= len(QParagrapgs.keys())):
            end = len(QParagrapgs.keys())
            toggle = True
        chunk=chunk+1
        paraEncodings = {}
        for i in range(start, end + 1):
            paraEncodings[i] = QParagrapgs[i]
        qEncoding = np.mean(list(paraEncodings.values()), axis=0)
        dot = np.dot(DocEncoding, qEncoding)
        normd = np.linalg.norm(DocEncoding)
        normq = np.linalg.norm(qEncoding)
        paraScore = dot / (normd * normq)
        paraScores[count] = paraScore
        count = count + 1
        if (paraScore > MaxScore):
            MaxScore = paraScore
        SumScore = SumScore + paraScore
        if (toggle):
            break
    SumScore = SumScore / chunk
    if maxFlag == True:
        return MaxScore
    else:
        # print("computing avg score")
        return SumScore

# the following method loads candidate article encoding from a file that has the encoding either from the CLS vector or from the average pooling of the article tokens
def loadDocEncodingFromCLSPooledEncodings(DocFile,CLS=True):
    fq = open(DocFile, encoding='utf-8')
    content = ""
    for line in fq:
        content = content + line
    clspooled = content.split("<Pooled>")
    if (CLS):
        content = clspooled[0].strip()
    else:
        content = clspooled[1].strip()
    qEncoding = []
    data = content.strip().split(" ")
    for d in data:
        qEncoding.append(np.float32(d))
    return qEncoding

def accessDatabase(statement):
    # print("Executing statement",statement)
    mydb = pymysql.connect(
        host="localhost",
        user="root",
        password="123456789",
        db="WPostDBV4"
    )

    mycursor = mydb.cursor()

    mycursor.execute(statement)

    myresult = mycursor.fetchall()

    return myresult

def getQueriesId(queriesfile):
    toggle = True
    queriesIds = {}
    with open(queriesfile, encoding='utf-8') as f:
        for line in f:
            if toggle:
                data = line.split(",")
                queriesIds[data[1]] = data[0]
                toggle = False
            else:
                toggle = True
    return queriesIds

def loadCandidateIdsFromBaselineFile(baselineFile):
    CandidateIds=[]
    with open(baselineFile, encoding='utf-8') as f:
        for line in f:
            CandidateIds.append(line.split(" ")[2])

def LoadDocumentEncodingFromFile(docFile):
    dEncoding = []
    try:
        with open(docFile, encoding='utf-8') as f:
            for line in f:
                data = line.strip().split(" ")
                for d in data:
                    dEncoding.append(np.float32(d))
    except Exception as e:
        print(e)
        print("no file found for document", docFile)
        return dEncoding
    return dEncoding

#The reranking process of candidates taking the queries encoding file and the document encoding file.
def rerankDocBasedOnQueryPara_WholeDocSlidedPara(queriesfile, runfile, resultfile, QueryDir, alpha, docEncodingDir, maxFlag,
                                             window):
    queriesIds = getQueriesId(queriesfile)
    # model = SentenceTransformer('all-mpnet-base-v2')
    fw = open(resultfile, "w")
    qParaEncodings = loadQueryParagraphEncodings(queriesIds, QueryDir)
    Query = "-1"
    queryDocsSemantic = {}
    queryDocsLexical = {}
    queryDocsFinalScore = {}
    docs = {}
    with open(runfile, encoding='utf-8') as f:
        for line in f:
            data = line.split(" ")
            if (data[0] != Query):
                if (Query != "-1"):  # already done with a query, write it to the output file
                    # Aggregating all lexical scores for a query to compute normalized score
                    #print("writing into output file results for query", Query)
                    min = 100000000
                    max = 0
                    for k in queryDocsLexical.keys():
                        if (queryDocsLexical[k] > max):
                            max = queryDocsLexical[k]
                        if (queryDocsLexical[k] < min):
                            min = queryDocsLexical[k]
                    for k in queryDocsSemantic.keys():
                        #print(Query,queryDocsLexical[k],queryDocsSemantic[k])
                        LexicalScore = (queryDocsLexical[k] - min) / (max - min)
                        queryDocsFinalScore[k] = ((1.0 - alpha) * LexicalScore) + (
                                alpha * queryDocsSemantic[k])  # applying the interpolation
                    queryDocsFinalScore = {k: v for k, v in
                                           sorted(queryDocsFinalScore.items(), key=lambda item: item[1],
                                                  reverse=True)}  # Now Sorting and printing
                    print("-------------------------------------------")
                    for k in queryDocsFinalScore.keys():
                        fw.write(Query + " Q0 " + k + " 0 " + str(queryDocsFinalScore[k]) + " DenseRunCS\n")
                    queryDocsSemantic = {}
                    queryDocsLexical = {}
                    queryDocsFinalScore = {}

                Query = data[0]
            docID = data[2]
            docs[docID] = 0
            # try:
            docVector = LoadDocumentEncodingFromFile(
                docEncodingDir + "/" + docID)  # loading the encoding of the document from the encoding dir
            #print(Query,docVector)
            if len(docVector) == 0:
                print("faulty document None", docID)
                queryDocsSemantic[data[2]] = 0.0
                queryDocsLexical[data[2]] = float(data[4])
                continue
            queryDocsSemantic[data[2]] = getDocumentScoreFromQueryParaSlided(qParaEncodings[Query], docVector, maxFlag,
                                                                             window)
            queryDocsLexical[data[2]] = float(data[4])

    min = 100000000
    max = 0
    for k in queryDocsLexical.keys():
        if (queryDocsLexical[k] > max):
            max = queryDocsLexical[k]
        if (queryDocsLexical[k] < min):
            min = queryDocsLexical[k]

    for k in queryDocsSemantic.keys():
        LexicalScore = (queryDocsLexical[k] - min) / (max - min)
        queryDocsFinalScore[k] = ((1.0 - alpha) * LexicalScore) + (
                    alpha * queryDocsSemantic[k])  # applying the interpolation

    queryDocsFinalScore = {k: v for k, v in sorted(queryDocsFinalScore.items(), key=lambda item: item[1],
                                                   reverse=True)}  # Now Sorting and printing
    for k in queryDocsFinalScore.keys():
        fw.write(Query + " Q0 " + k + " 0 " + str(queryDocsFinalScore[k]) + " DenseRunCS\n")
    fw.close()
    print("Processed", len(docs), " Unique documents in File")



