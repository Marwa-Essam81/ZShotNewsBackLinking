# The following methods calculate an integration between the lexical and the semantic relevance signals as described in the paper.
# The infile is a file that has the lexical and the semantic scores calculated for each candidate article formated as
# <query> space <doc> space <lexical_score> <semantic_score>

def interpolateRankings(baselinefile,secondrunfile,interpolatedfile,alpha):
    fw = open(interpolatedfile, "w")
    #1- loading document scores from second run file
    queriesDocsScore2nd={}
    f = open(secondrunfile, encoding='utf-8')
    for line in f.readlines():
        data=line.split(" ")
        query=data[0]
        doc = data[2]
        score=float(data[4])
        if queriesDocsScore2nd.keys().__contains__(query)!=True:
            queriesDocsScore2nd[query] = {}
        queriesDocsScore2nd[query][doc]=score
    #2- Reading the baseline file, normalize using 0,1 then interpolated
    #########
    Query = "-1"
    queryDocsLexical = {}
    queryDocsFinalScore = {}
    docs = {}
    with open(baselinefile, encoding='utf-8') as f:
        for line in f:
            data = line.split(" ")
            if (data[0] != Query):
                if (Query != "-1"):  # already done with a query, write it to the output file
                    # Aggregating all lexical scores for a query to compute normalized score
                    print("writing into output file results for query", Query)
                    min = 100000000
                    max = 0
                    for k in queryDocsLexical.keys():
                        if (queryDocsLexical[k] > max):
                            max = queryDocsLexical[k]
                        if (queryDocsLexical[k] < min):
                            min = queryDocsLexical[k]
                    for k in queriesDocsScore2nd[Query].keys():
                        LexicalScore = (queryDocsLexical[k] - min) / (max - min)
                        queryDocsFinalScore[k] = ((1.0 - alpha) * LexicalScore) + (
                                alpha * queriesDocsScore2nd[Query][k])  # applying the interpolation
                    queryDocsFinalScore = {k: v for k, v in
                                           sorted(queryDocsFinalScore.items(), key=lambda item: item[1],
                                                  reverse=True)}  # Now Sorting and printing
                    for k in queryDocsFinalScore.keys():
                        fw.write(Query + " Q0 " + k + " 0 " + str(queryDocsFinalScore[k]) + " DenseRunCS\n")
                    queryDocsLexical = {}
                    queryDocsFinalScore = {}

                Query = data[0]
            docID = data[2]
            queryDocsLexical[docID] = float(data[4])

    min = 100000000
    max = 0
    for k in queryDocsLexical.keys():
        if (queryDocsLexical[k] > max):
            max = queryDocsLexical[k]
        if (queryDocsLexical[k] < min):
            min = queryDocsLexical[k]

    for k in queriesDocsScore2nd[Query].keys():
        LexicalScore = (queryDocsLexical[k] - min) / (max - min)
        queryDocsFinalScore[k] = ((1.0 - alpha) * LexicalScore) + (
                alpha * queriesDocsScore2nd[Query][k])  # applying the interpolation

    queryDocsFinalScore = {k: v for k, v in sorted(queryDocsFinalScore.items(), key=lambda item: item[1],
                                                   reverse=True)}  # Now Sorting and printing
    for k in queryDocsFinalScore.keys():
        fw.write(Query + " Q0 " + k + " 0 " + str(queryDocsFinalScore[k]) + " DenseRunCS\n")
    fw.close()

def ReadAndInterpolate(infile,outfile):
    QueryLexicalScores={}
    QuerySemanticScores={}
    f=open(infile, encoding='utf-8')
    for line in f.readlines():
        try:
            data=line.split(" ")
            query=data[0]
            doc=data[1]
            lexicalScore=float(data[2])
            semanticScore=float(data[3])
            if(QueryLexicalScores.keys().__contains__(query)):
                QueryLexicalScores[query][doc]=lexicalScore
                QuerySemanticScores[query][doc] = semanticScore
            else:
                QueryLexicalScores[query]={}
                QuerySemanticScores[query]={}
                QueryLexicalScores[query][doc] = lexicalScore
                QuerySemanticScores[query][doc] = semanticScore
        except:
            print(line)
    alpha=0.0
    filename=0
    while(alpha<=1.0):
        fw = open(outfile+"_"+str(filename)+".txt", "w")
        for query in QueryLexicalScores.keys():
            queryfinalscores = {}
            for doc in QueryLexicalScores[query].keys():
                queryfinalscores[doc]= ((1.0 - alpha) * QueryLexicalScores[query][doc]) + (
                        alpha * QuerySemanticScores[query][doc])  # applying the interpolation
            queryfinalscores = {k: v for k, v in
                                       sorted(queryfinalscores.items(), key=lambda item: item[1],
                                              reverse=True)}  # Now Sorting and printing
            for k in queryfinalscores.keys():
                    fw.write(query + " Q0 " + k + " 0 " + str(queryfinalscores[k]) + " DenseRunCS\n")
        fw.close()
        alpha=round(alpha+0.1,1)
        filename=filename+10

    print("done")

def ReadAndInterpolateNorm(infile,outfile):
    QueryLexicalScores={}
    QuerySemanticScores={}
    f=open(infile, encoding='utf-8')
    for line in f.readlines():
        try:
            data=line.split(" ")
            query=data[0]
            doc=data[1]
            lexicalScore=float(data[2])
            semanticScore=float(data[3])
            if(QueryLexicalScores.keys().__contains__(query)):
                QueryLexicalScores[query][doc]=lexicalScore
                QuerySemanticScores[query][doc] = semanticScore
            else:
                QueryLexicalScores[query]={}
                QuerySemanticScores[query]={}
                QueryLexicalScores[query][doc] = lexicalScore
                QuerySemanticScores[query][doc] = semanticScore
        except:
            print(line)
    alpha=0.0
    filename=0
    while(alpha<=1.0):
        fw = open(outfile+"_"+str(filename)+".txt", "w")

        for query in QueryLexicalScores.keys():
            maximum=0
            min=10000
            for doc in QuerySemanticScores[query].keys():
                if(QuerySemanticScores[query][doc]>maximum):
                    maximum=QuerySemanticScores[query][doc]
                if(QuerySemanticScores[query][doc]<min):
                    min=QuerySemanticScores[query][doc]


            queryfinalscores = {}
            for doc in QueryLexicalScores[query].keys():
                normsemanticScore=(QuerySemanticScores[query][doc]-min)/(maximum-min)
                queryfinalscores[doc]= ((1.0 - alpha) * QueryLexicalScores[query][doc]) + (
                        alpha * normsemanticScore)  # applying the interpolation
            queryfinalscores = {k: v for k, v in
                                       sorted(queryfinalscores.items(), key=lambda item: item[1],
                                              reverse=True)}  # Now Sorting and printing
            for k in queryfinalscores.keys():
                    fw.write(query + " Q0 " + k + " 0 " + str(queryfinalscores[k]) + " DenseRunCS\n")
        fw.close()
        alpha=round(alpha+0.1,1)
        filename=filename+10
    print("done")

def ReadAndInterpolateNormProduct(infile,outfile):
    QueryLexicalScores={}
    QuerySemanticScores={}
    f=open(infile, encoding='utf-8')
    for line in f.readlines():
        try:
            data=line.split(" ")
            query=data[0]
            doc=data[1]
            lexicalScore=float(data[2])
            semanticScore=float(data[3])
            if(QueryLexicalScores.keys().__contains__(query)):
                QueryLexicalScores[query][doc]=lexicalScore
                QuerySemanticScores[query][doc] = semanticScore
            else:
                QueryLexicalScores[query]={}
                QuerySemanticScores[query]={}
                QueryLexicalScores[query][doc] = lexicalScore
                QuerySemanticScores[query][doc] = semanticScore
        except:
            print(line)
    alpha=1.0
    filename=0
    while(alpha<=1.0):
        fw = open(outfile+"_"+str(filename)+".txt", "w")

        for query in QueryLexicalScores.keys():
            maximum=0
            min=10000
            for doc in QuerySemanticScores[query].keys():
                if(QuerySemanticScores[query][doc]>maximum):
                    maximum=QuerySemanticScores[query][doc]
                if(QuerySemanticScores[query][doc]<min):
                    min=QuerySemanticScores[query][doc]

            queryfinalscores = {}
            for doc in QueryLexicalScores[query].keys():
                normsemanticScore=(QuerySemanticScores[query][doc]-min)/(maximum-min)
                queryfinalscores[doc]=(normsemanticScore*QueryLexicalScores[query][doc])            queryfinalscores = {k: v for k, v in
                                       sorted(queryfinalscores.items(), key=lambda item: item[1],
                                              reverse=True)}  # Now Sorting and printing
            for k in queryfinalscores.keys():
                    fw.write(query + " Q0 " + k + " 0 " + str(queryfinalscores[k]) + " DenseRunCS\n")
        fw.close()
        alpha=round(alpha+0.1,1)
        filename=filename+10
    print("done")

def ReadAndInterpolateWeightedRanks(infile,outfile):
    QueryLexicalScores={}
    QuerySemanticScores={}
    f=open(infile, encoding='utf-8')
    for line in f.readlines():
        try:
            data=line.split(" ")
            query=data[0]
            doc=data[1]
            lexicalScore=float(data[2])
            semanticScore=float(data[3])
            if(QueryLexicalScores.keys().__contains__(query)):
                QueryLexicalScores[query][doc]=lexicalScore
                QuerySemanticScores[query][doc] = semanticScore
            else:
                QueryLexicalScores[query]={}
                QuerySemanticScores[query]={}
                QueryLexicalScores[query][doc] = lexicalScore
                QuerySemanticScores[query][doc] = semanticScore
        except:
            print(line)
    alpha=0.0
    filename=0
    while(alpha<=1.0):
        fw = open(outfile+"_"+str(filename)+".txt", "w")

        for query in QueryLexicalScores.keys():

            SemanticDocsSorted = {k: v for k, v in
                                sorted(QuerySemanticScores[query].items(), key=lambda item: item[1],
                                       reverse=True)}  # Now Sorting and printing
            SemanticDocsRank={}
            rank=len(SemanticDocsSorted.keys())
            for k in SemanticDocsSorted.keys():
                SemanticDocsRank[k]=rank
                rank=rank-1

            LexicalDocsSorted = {k: v for k, v in
                                sorted(QueryLexicalScores[query].items(), key=lambda item: item[1],
                                       reverse=True)}  # Now Sorting and printing
            LexicalDocsRank = {}
            rank = len(LexicalDocsSorted.keys())
            for k in LexicalDocsSorted.keys():
                LexicalDocsRank[k] = rank
                rank = rank - 1

            queryfinalscores = {}
            for doc in QueryLexicalScores[query].keys():

                queryfinalscores[doc]= ((1.0 - alpha) * LexicalDocsRank[doc]) + (
                        alpha * SemanticDocsRank[doc])  # applying the interpolation
            queryfinalscores = {k: v for k, v in
                                       sorted(queryfinalscores.items(), key=lambda item: item[1],
                                              reverse=True)}  # Now Sorting and printing
            for k in queryfinalscores.keys():
                    fw.write(query + " Q0 " + k + " 0 " + str(queryfinalscores[k]) + " DenseRunCS\n")
        fw.close()
        alpha=round(alpha+0.1,1)
        filename=filename+10

    print("done")

def ReadAndInterpolateBordaRanks(infile,outfile):
    QueryLexicalScores={}
    QuerySemanticScores={}
    f=open(infile, encoding='utf-8')
    for line in f.readlines():
        try:
            data=line.split(" ")
            query=data[0]
            doc=data[1]
            lexicalScore=float(data[2])
            semanticScore=float(data[3])
            if(QueryLexicalScores.keys().__contains__(query)):
                QueryLexicalScores[query][doc]=lexicalScore
                QuerySemanticScores[query][doc] = semanticScore
            else:
                QueryLexicalScores[query]={}
                QuerySemanticScores[query]={}
                QueryLexicalScores[query][doc] = lexicalScore
                QuerySemanticScores[query][doc] = semanticScore
        except:
            print(line)
    alpha=0.0
    filename=0
    while(alpha<=1.0):
        fw = open(outfile+"_"+str(filename)+".txt", "w")

        for query in QueryLexicalScores.keys():

            SemanticDocsSorted = {k: v for k, v in
                                sorted(QuerySemanticScores[query].items(), key=lambda item: item[1],
                                       reverse=True)}  # Now Sorting and printing
            SemanticDocsRank={}
            rank=1
            for k in SemanticDocsSorted.keys():
                SemanticDocsRank[k]=rank
                rank=rank+1
            for k in SemanticDocsRank.keys():
                SemanticDocsRank[k]=1-((SemanticDocsRank[k]-1)/100)

            LexicalDocsSorted = {k: v for k, v in
                                sorted(QueryLexicalScores[query].items(), key=lambda item: item[1],
                                       reverse=True)}  # Now Sorting and printing
            LexicalDocsRank = {}
            rank = 1
            for k in LexicalDocsSorted.keys():
                LexicalDocsRank[k] = rank
                rank = rank + 1
            for k in LexicalDocsSorted.keys():
                LexicalDocsRank[k]=1-((LexicalDocsRank[k]-1)/100)

            queryfinalscores = {}
            for doc in QueryLexicalScores[query].keys():
                NormSemanticRank=SemanticDocsRank[doc]
                NormLexicalRank=LexicalDocsRank[doc]
                queryfinalscores[doc]= ((1.0 - alpha) * NormLexicalRank) + (
                        alpha * NormSemanticRank)  # applying the interpolation
            queryfinalscores = {k: v for k, v in
                                       sorted(queryfinalscores.items(), key=lambda item: item[1],
                                              reverse=True)}  # Now Sorting and printing
            for k in queryfinalscores.keys():
                    fw.write(query + " Q0 " + k + " 0 " + str(queryfinalscores[k]) + " DenseRunCS\n")
        fw.close()
        alpha=round(alpha+0.1,1)
        filename=filename+10





    print("done")

def ReadAndInterpolateDowdallRanks(infile,outfile):
    QueryLexicalScores={}
    QuerySemanticScores={}
    f=open(infile, encoding='utf-8')
    for line in f.readlines():
        try:
            data=line.split(" ")
            query=data[0]
            doc=data[1]
            lexicalScore=float(data[2])
            semanticScore=float(data[3])
            if(QueryLexicalScores.keys().__contains__(query)):
                QueryLexicalScores[query][doc]=lexicalScore
                QuerySemanticScores[query][doc] = semanticScore
            else:
                QueryLexicalScores[query]={}
                QuerySemanticScores[query]={}
                QueryLexicalScores[query][doc] = lexicalScore
                QuerySemanticScores[query][doc] = semanticScore
        except:
            print(line)
    alpha=0.0
    filename=0
    while(alpha<=1.0):
        fw = open(outfile+"_"+str(filename)+".txt", "w")

        for query in QueryLexicalScores.keys():

            SemanticDocsSorted = {k: v for k, v in
                                sorted(QuerySemanticScores[query].items(), key=lambda item: item[1],
                                       reverse=True)}  # Now Sorting and printing
            SemanticDocsRank={}
            rank=1
            for k in SemanticDocsSorted.keys():
                SemanticDocsRank[k]=rank
                rank=rank+1

            LexicalDocsSorted = {k: v for k, v in
                                sorted(QueryLexicalScores[query].items(), key=lambda item: item[1],
                                       reverse=True)}  # Now Sorting and printing
            LexicalDocsRank = {}
            rank = 1
            for k in LexicalDocsSorted.keys():
                LexicalDocsRank[k] = rank
                rank = rank + 1

            queryfinalscores = {}
            for doc in QueryLexicalScores[query].keys():
                NormSemanticRank=1/SemanticDocsRank[doc]
                NormLexicalRank=1/LexicalDocsRank[doc]
                queryfinalscores[doc]= ((1.0 - alpha) * NormLexicalRank) + (
                        alpha * NormSemanticRank)  # applying the interpolation
            queryfinalscores = {k: v for k, v in
                                       sorted(queryfinalscores.items(), key=lambda item: item[1],
                                              reverse=True)}  # Now Sorting and printing
            for k in queryfinalscores.keys():
                    fw.write(query + " Q0 " + k + " 0 " + str(queryfinalscores[k]) + " DenseRunCS\n")
        fw.close()
        alpha=round(alpha+0.1,1)
        filename=filename+10





    print("done")

def ReadAndInterpolateRankAggregation(infile,outfile):
    QueryLexicalScores={}
    QuerySemanticScores={}
    f=open(infile, encoding='utf-8')
    for line in f.readlines():
        try:
            data=line.split(" ")
            query=data[0]
            doc=data[1]
            lexicalScore=float(data[2])
            semanticScore=float(data[3])
            if(QueryLexicalScores.keys().__contains__(query)):
                QueryLexicalScores[query][doc]=lexicalScore
                QuerySemanticScores[query][doc] = semanticScore
            else:
                QueryLexicalScores[query]={}
                QuerySemanticScores[query]={}
                QueryLexicalScores[query][doc] = lexicalScore
                QuerySemanticScores[query][doc] = semanticScore
        except:
            print(line)
    alpha=1.0
    filename=0
    while(alpha<=1.0):
        fw = open(outfile+"_"+str(filename)+".txt", "w")

        for query in QueryLexicalScores.keys():

            SemanticDocsSorted = {k: v for k, v in
                                sorted(QuerySemanticScores[query].items(), key=lambda item: item[1],
                                       reverse=True)}  # Now Sorting and printing
            SemanticDocsRank={}
            rank=len(SemanticDocsSorted.keys())-1
            for k in SemanticDocsSorted.keys():
                SemanticDocsRank[k]=rank
                rank=rank-1

            LexicalDocsSorted = {k: v for k, v in
                                sorted(QueryLexicalScores[query].items(), key=lambda item: item[1],
                                       reverse=True)}  # Now Sorting and printing
            LexicalDocsRank = {}
            rank = len(LexicalDocsSorted.keys())-1
            for k in LexicalDocsSorted.keys():
                LexicalDocsRank[k] = rank
                rank = rank - 1

            queryfinalscores = {}
            for doc in QueryLexicalScores[query].keys():

                queryfinalscores[doc]= (LexicalDocsRank[doc]) + (SemanticDocsRank[doc])  # applying the interpolation
            queryfinalscores = {k: v for k, v in
                                       sorted(queryfinalscores.items(), key=lambda item: item[1],
                                              reverse=True)}  # Now Sorting and printing
            for k in queryfinalscores.keys():
                    fw.write(query + " Q0 " + k + " 0 " + str(queryfinalscores[k]) + " DenseRunCS\n")
        fw.close()
        alpha=round(alpha+0.1,1)
        filename=filename+10





    print("done")

def ReadAndInterpolateSumNorm(infile,outfile):
    QueryLexicalScores={}
    QuerySemanticScores={}
    f=open(infile, encoding='utf-8')
    for line in f.readlines():
        try:
            data=line.split(" ")
            query=data[0]
            doc=data[1]
            lexicalScore=float(data[2])
            semanticScore=float(data[3])
            if(QueryLexicalScores.keys().__contains__(query)):
                QueryLexicalScores[query][doc]=lexicalScore
                QuerySemanticScores[query][doc] = semanticScore
            else:
                QueryLexicalScores[query]={}
                QuerySemanticScores[query]={}
                QueryLexicalScores[query][doc] = lexicalScore
                QuerySemanticScores[query][doc] = semanticScore
        except:
            print(line)
    alpha=0.0
    filename=0
    while(alpha<=1.0):
        fw = open(outfile+"_"+str(filename)+".txt", "w")

        for query in QueryLexicalScores.keys():
            SumSemantic=0
            SumLexical=0
            for doc in QuerySemanticScores[query].keys():
                SumSemantic=SumSemantic+QuerySemanticScores[query][doc]
                SumLexical=SumLexical+QueryLexicalScores[query][doc]



            queryfinalscores = {}
            for doc in QueryLexicalScores[query].keys():
                normsemanticScore=QuerySemanticScores[query][doc]/SumSemantic
                normlexicalScore = QueryLexicalScores[query][doc] / SumLexical

                queryfinalscores[doc]= ((1.0 - alpha) * normlexicalScore) + (
                        alpha * normsemanticScore)  # applying the interpolation
            queryfinalscores = {k: v for k, v in
                                       sorted(queryfinalscores.items(), key=lambda item: item[1],
                                              reverse=True)}  # Now Sorting and printing
            for k in queryfinalscores.keys():
                    fw.write(query + " Q0 " + k + " 0 " + str(queryfinalscores[k]) + " DenseRunCS\n")
        fw.close()
        alpha=round(alpha+0.1,1)
        filename=filename+10





    print("done")

def ReadAndInterpolateSumNormThenMax(infile,outfile):
    QueryLexicalScores={}
    QuerySemanticScores={}
    f=open(infile, encoding='utf-8')
    for line in f.readlines():
        try:
            data=line.split(" ")
            query=data[0]
            doc=data[1]
            lexicalScore=float(data[2])
            semanticScore=float(data[3])
            if(QueryLexicalScores.keys().__contains__(query)):
                QueryLexicalScores[query][doc]=lexicalScore
                QuerySemanticScores[query][doc] = semanticScore
            else:
                QueryLexicalScores[query]={}
                QuerySemanticScores[query]={}
                QueryLexicalScores[query][doc] = lexicalScore
                QuerySemanticScores[query][doc] = semanticScore
        except:
            print(line)
    alpha=0.5
    filename=0
    while(alpha<=0.5):
        fw = open(outfile+"_"+str(filename)+".txt", "w")

        for query in QueryLexicalScores.keys():
            SumSemantic=0
            SumLexical=0
            for doc in QuerySemanticScores[query].keys():
                SumSemantic=SumSemantic+QuerySemanticScores[query][doc]
                SumLexical=SumLexical+QueryLexicalScores[query][doc]



            queryfinalscores = {}
            for doc in QueryLexicalScores[query].keys():
                normsemanticScore=QuerySemanticScores[query][doc]/SumSemantic
                normlexicalScore = QueryLexicalScores[query][doc] / SumLexical
                queryfinalscores[doc]=max(normsemanticScore,normlexicalScore)
            queryfinalscores = {k: v for k, v in
                                       sorted(queryfinalscores.items(), key=lambda item: item[1],
                                              reverse=True)}  # Now Sorting and printing

            for k in queryfinalscores.keys():
                    fw.write(query + " Q0 " + k + " 0 " + str(queryfinalscores[k]) + " DenseRunCS\n")
        fw.close()
        alpha=round(alpha+0.1,1)
        filename=filename+10





    print("done")

def ReadAndInterpolateSumNormThenMin(infile,outfile):
    QueryLexicalScores={}
    QuerySemanticScores={}
    f=open(infile, encoding='utf-8')
    for line in f.readlines():
        try:
            data=line.split(" ")
            query=data[0]
            doc=data[1]
            lexicalScore=float(data[2])
            semanticScore=float(data[3])
            if(QueryLexicalScores.keys().__contains__(query)):
                QueryLexicalScores[query][doc]=lexicalScore
                QuerySemanticScores[query][doc] = semanticScore
            else:
                QueryLexicalScores[query]={}
                QuerySemanticScores[query]={}
                QueryLexicalScores[query][doc] = lexicalScore
                QuerySemanticScores[query][doc] = semanticScore
        except:
            print(line)
    alpha=0.5
    filename=0
    while(alpha<=0.5):
        fw = open(outfile+"_"+str(filename)+".txt", "w")

        for query in QueryLexicalScores.keys():
            SumSemantic=0
            SumLexical=0
            for doc in QuerySemanticScores[query].keys():
                SumSemantic=SumSemantic+QuerySemanticScores[query][doc]
                SumLexical=SumLexical+QueryLexicalScores[query][doc]



            queryfinalscores = {}
            for doc in QueryLexicalScores[query].keys():
                normsemanticScore=QuerySemanticScores[query][doc]/SumSemantic
                normlexicalScore = QueryLexicalScores[query][doc] / SumLexical
                queryfinalscores[doc]=min(normsemanticScore,normlexicalScore)
            queryfinalscores = {k: v for k, v in
                                       sorted(queryfinalscores.items(), key=lambda item: item[1],
                                              reverse=True)}  # Now Sorting and printing

            for k in queryfinalscores.keys():
                    fw.write(query + " Q0 " + k + " 0 " + str(queryfinalscores[k]) + " DenseRunCS\n")
        fw.close()
        alpha=round(alpha+0.1,1)
        filename=filename+10





    print("done")

def ReadAndInterpolateSumNormThenMinMax(infile,outfile):
    QueryLexicalScores={}
    QuerySemanticScores={}
    f=open(infile, encoding='utf-8')
    for line in f.readlines():
        try:
            data=line.split(" ")
            query=data[0]
            doc=data[1]
            lexicalScore=float(data[2])
            semanticScore=float(data[3])
            if(QueryLexicalScores.keys().__contains__(query)):
                QueryLexicalScores[query][doc]=lexicalScore
                QuerySemanticScores[query][doc] = semanticScore
            else:
                QueryLexicalScores[query]={}
                QuerySemanticScores[query]={}
                QueryLexicalScores[query][doc] = lexicalScore
                QuerySemanticScores[query][doc] = semanticScore
        except:
            print(line)
    alpha=0.5
    filename=0
    while(alpha<=0.5):
        fw = open(outfile+"_"+str(filename)+".txt", "w")

        for query in QueryLexicalScores.keys():
            SumSemantic=0
            SumLexical=0
            for doc in QuerySemanticScores[query].keys():
                SumSemantic=SumSemantic+QuerySemanticScores[query][doc]
                SumLexical=SumLexical+QueryLexicalScores[query][doc]



            queryfinalscores = {}
            for doc in QueryLexicalScores[query].keys():
                normsemanticScore=QuerySemanticScores[query][doc]/SumSemantic
                normlexicalScore = QueryLexicalScores[query][doc] / SumLexical

                DocMax=max(normsemanticScore,normlexicalScore)
                DocMin = min(normsemanticScore, normlexicalScore)
                queryfinalscores[doc]=DocMax+((DocMin*DocMin)/(DocMax+DocMin))
            queryfinalscores = {k: v for k, v in
                                       sorted(queryfinalscores.items(), key=lambda item: item[1],
                                              reverse=True)}  # Now Sorting and printing
            for k in queryfinalscores.keys():
                    fw.write(query + " Q0 " + k + " 0 " + str(queryfinalscores[k]) + " DenseRunCS\n")
        fw.close()
        alpha=round(alpha+0.1,1)
        filename=filename+10





    print("done")

def ReadAndInterpolateSumNormThenProduct(infile,outfile):
    QueryLexicalScores={}
    QuerySemanticScores={}
    f=open(infile, encoding='utf-8')
    for line in f.readlines():
        try:
            data=line.split(" ")
            query=data[0]
            doc=data[1]
            lexicalScore=float(data[2])
            semanticScore=float(data[3])
            if(QueryLexicalScores.keys().__contains__(query)):
                QueryLexicalScores[query][doc]=lexicalScore
                QuerySemanticScores[query][doc] = semanticScore
            else:
                QueryLexicalScores[query]={}
                QuerySemanticScores[query]={}
                QueryLexicalScores[query][doc] = lexicalScore
                QuerySemanticScores[query][doc] = semanticScore
        except:
            print(line)
    alpha=0.5
    filename=0
    while(alpha<=0.5):
        fw = open(outfile+"_"+str(filename)+".txt", "w")

        for query in QueryLexicalScores.keys():
            SumSemantic=0
            SumLexical=0
            for doc in QuerySemanticScores[query].keys():
                SumSemantic=SumSemantic+QuerySemanticScores[query][doc]
                SumLexical=SumLexical+QueryLexicalScores[query][doc]



            queryfinalscores = {}
            for doc in QueryLexicalScores[query].keys():
                normsemanticScore=QuerySemanticScores[query][doc]/SumSemantic
                normlexicalScore = QueryLexicalScores[query][doc] / SumLexical
                queryfinalscores[doc]=normsemanticScore*normlexicalScore
                #queryfinalscores[doc]= ((1.0 - alpha) * normlexicalScore) + (
                #        alpha * normsemanticScore)  # applying the interpolation
            queryfinalscores = {k: v for k, v in
                                       sorted(queryfinalscores.items(), key=lambda item: item[1],
                                              reverse=True)}  # Now Sorting and printing
            for k in queryfinalscores.keys():
                    fw.write(query + " Q0 " + k + " 0 " + str(queryfinalscores[k]) + " DenseRunCS\n")
        fw.close()
        alpha=round(alpha+0.1,1)
        filename=filename+10

    print("done")

def getMeanAndVariance(values):
    mean = sum(values) / len(values)
    differences = [(value - mean) ** 2 for value in values]
    sum_of_differences = sum(differences)
    standard_deviation = (sum_of_differences / (len(values) - 1)) ** 0.5
    return mean, standard_deviation

def ReadAndInterpolateZNorm(infile,outfile):
    QueryLexicalScores={}
    QuerySemanticScores={}
    f=open(infile, encoding='utf-8')
    for line in f.readlines():
        try:
            data=line.split(" ")
            query=data[0]
            doc=data[1]
            lexicalScore=float(data[2])
            semanticScore=float(data[3])
            if(QueryLexicalScores.keys().__contains__(query)):
                QueryLexicalScores[query][doc]=lexicalScore
                QuerySemanticScores[query][doc] = semanticScore
            else:
                QueryLexicalScores[query]={}
                QuerySemanticScores[query]={}
                QueryLexicalScores[query][doc] = lexicalScore
                QuerySemanticScores[query][doc] = semanticScore
        except:
            print(line)
    alpha=0.0
    filename=0
    while(alpha<=1.0):
        fw = open(outfile+"_"+str(filename)+".txt", "w")

        for query in QueryLexicalScores.keys():
            SumSemantic=0
            SumLexical=0
            SemanticValues=[]
            for doc in QuerySemanticScores[query].keys():
                SemanticValues.append(QuerySemanticScores[query][doc])
            LexicalValues = []
            for doc in QueryLexicalScores[query].keys():
                LexicalValues.append(QueryLexicalScores[query][doc])


            SemanticMean,SemanticVariance=getMeanAndVariance(SemanticValues)
            LexicalMean, LexicalVariance = getMeanAndVariance(LexicalValues)

            queryfinalscores = {}
            for doc in QueryLexicalScores[query].keys():
                normsemanticScore=(QuerySemanticScores[query][doc]-SemanticMean)/SemanticVariance
                normlexicalScore = (QueryLexicalScores[query][doc]-LexicalMean) / LexicalVariance
                #print(normsemanticScore, normlexicalScore)
                queryfinalscores[doc]= ((1.0 - alpha) * normlexicalScore) + (
                        alpha * normsemanticScore)  # applying the interpolation
            queryfinalscores = {k: v for k, v in
                                       sorted(queryfinalscores.items(), key=lambda item: item[1],
                                              reverse=True)}  # Now Sorting and printing

            score=len(queryfinalscores.keys())
            for k in queryfinalscores.keys():
                fw.write(query + " Q0 " + k + " 0 " + str(queryfinalscores[k]) + " DenseRunCS\n")
                score=score-1
        fw.close()
        alpha=round(alpha+0.1,1)
        filename=filename+10





    print("done")


if __name__ == '__main__':
	#Call the required integration function to integrate the lexical and the semantic scores as shown in the paper
	#For example,
	ReadAndInterpolateSumNorm("QueriesMatchSignals.txt","Integratetion_SunOfScores_Run.txt")
	print("done")
