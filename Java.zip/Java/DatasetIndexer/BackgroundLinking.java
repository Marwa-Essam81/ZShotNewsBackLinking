package DatasetIndexer;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Map;
import java.util.stream.Collectors;

import org.apache.lucene.document.Document;
import org.apache.lucene.index.DirectoryReader;
import org.apache.lucene.index.IndexReader;
import org.apache.lucene.index.Term;
import org.apache.lucene.search.IndexSearcher;
import org.apache.lucene.search.ScoreDoc;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document.OutputSettings;
import org.jsoup.nodes.Entities.EscapeMode;
import org.jsoup.parser.Parser;
import org.jsoup.safety.Whitelist;
import org.tartarus.snowball.ext.EnglishStemmer;

public class BackgroundLinking {

	public static void main(String[] args) {
		/**
		 * To retrieve an initial set of background links. You need to pass to this
		 * method: the index name, a file with the queries information,the location to a
		 * directory where each query has a text file with its title concatenated with
		 * its content after removing the html tags, The output directory, the output run
		 * file name, the output log file name, -1 (this parameter means that you do not
		 * limit the size of the search query to a specific number of terms, false (this
		 * parameter means that you will not use idf only as boost for term
		 * weighting during the retrieval process.
		 * For copyright issues, the directory "QueriesTxt" that contains the text of the queries is not given. Once you create the database, 
		 * use it to create a file for the text of each query. The file queries.txt has the unique docid of each query. **/
		
		processQueriesTFIDF("V3Index_Stemmed.index", "QueriesInfo.txt", "QueriesTxt", "OutputDir", "Baseline.txt",
				"Baseline_log.txt", -1, false);
	}

	/**
	 * The following method calculates the TF/IDF values for terms in the given text
	 * 
	 * @param text
	 * @param idf
	 * @param numTerms
	 * @param lindex
	 * @return
	 */
	public static String getTermsTFIDF(String text, boolean idf, int numTerms, String lindex) {
		HashMap<String, Double> terms = new HashMap<String, Double>();
		String searchQuery = "";
		String[] tokens = text.split("\\s+");
		for (int i = 0; i < tokens.length; i++) {
			if (terms.containsKey(tokens[i])) {
				double count = terms.get(tokens[i]);
				terms.put(tokens[i], count + 1);
			} else
				terms.put(tokens[i], 1.0);
		}

		if (idf) {
			try {
				luceneIndex index = new luceneIndex(lindex);
				IndexReader reader = DirectoryReader.open(index.iIndex);
				int totalNumDocs = reader.numDocs();

				HashMap<String, Double> termsIdf = new HashMap<String, Double>();
				for (Map.Entry me : terms.entrySet()) {
					String term = (String) me.getKey();
					double v = (Double) me.getValue();
					int df = reader.docFreq(new Term("body", term));
					termsIdf.put(term, v * Math.log(totalNumDocs / df));
				}
				terms = termsIdf;
			} catch (Exception e) {
				e.printStackTrace();
			}

		}
		ArrayList termBoosts_Sorted = (ArrayList) terms.entrySet().stream()
				.sorted(HashMap.Entry.comparingByValue(Comparator.reverseOrder())).collect(Collectors.toList());
		int processedKeywords = 0;
		for (int i = 0; i < termBoosts_Sorted.size(); i++) {

			searchQuery = searchQuery + termBoosts_Sorted.get(i).toString().replace("=", "^") + " ";
			processedKeywords = processedKeywords + 1;
			if (numTerms != -1)
				if (processedKeywords == numTerms)
					break;
		}
		return searchQuery;
	}

	/**
	 * The following method retrieves the text of a query article
	 * 
	 * @param filename
	 * @return
	 */
	public static String getQueryBody(String filename) {
		String body = "";
		try {
			FileReader fileReader = new FileReader(filename);

			BufferedReader bufferedReader = new BufferedReader(fileReader);
			while (true) {
				String line = bufferedReader.readLine();
				if (line == null)
					break;
				if (line.contentEquals("Background Information:"))
					continue;
				if (line.toLowerCase().contentEquals("subtopics"))
					continue;
				if (line.strip().equals(""))
					continue;

				body = body + " " + line;
			}
		}

		catch (Exception te) {
		}
		return body;
	}

	/**
	 * 
	 * 
	 * /** A method that applies pre-processing to the text (i.e stop words removal,
	 * lower casing,...)
	 * 
	 * @param input
	 * @param lowercase
	 * @param stopWordsRemoval
	 * @param stopWords
	 * @param stem
	 * @param minTokenLength
	 * @return
	 */
	public static String preProcessStringStopWordsRemoved(String input, boolean lowercase, boolean stopWordsRemoval,
			ArrayList<String> stopWords, boolean stem, int minTokenLength) {
		// First Step is to filter the text to remove any remaining HTML content
		OutputSettings settings = new OutputSettings();
		settings.escapeMode(EscapeMode.base);
		String cleanHtml = Jsoup.clean(input, " ", Whitelist.none(), settings);
		cleanHtml = Parser.unescapeEntities(cleanHtml, false); // rempoving the &nbsp; resulted from parsing the html

		if (lowercase)
			cleanHtml = cleanHtml.toLowerCase();
		String finaltxt = "";
		if (stopWordsRemoval) {
			String[] substrings = cleanHtml.split(" ");

			for (int i = 0; i < substrings.length; i++)
				if (!stopWords.contains(substrings[i].toLowerCase()))
					finaltxt = finaltxt + substrings[i] + " ";
		} else
			finaltxt = cleanHtml;
		// Now remove all non alphapetical characters and all extra spaces.
		finaltxt = finaltxt.trim().replaceAll("[^A-Za-z ]", " ").replaceAll("( )+", " ");
		// Make sure that no stop words are there after special character removal
		String finaltxt1 = "";
		if (stopWordsRemoval) {
			String[] substrings = finaltxt.split(" ");

			for (int i = 0; i < substrings.length; i++)
				if (!stopWords.contains(substrings[i].toLowerCase()))
					finaltxt1 = finaltxt1 + substrings[i] + " ";
		} else
			finaltxt1 = finaltxt;

		// Now removing all token less than min in length
		cleanHtml = "";
		if (minTokenLength > 0) {
			String[] substrings = finaltxt1.split(" ");
			for (int i = 0; i < substrings.length; i++)
				if (substrings[i].length() >= minTokenLength)
					cleanHtml = cleanHtml + substrings[i] + " ";
			finaltxt1 = cleanHtml;
		}

		// we need to apply stemming here if requested

		String output = "";
		if (stem) {

			EnglishStemmer english = new EnglishStemmer();
			String[] words = finaltxt1.split(" ");
			for (int i = 0; i < words.length; i++) {
				english.setCurrent(words[i]);
				english.stem();
				output = output + english.getCurrent() + " ";
			}
		} else
			output = finaltxt1;
		return output.strip();

	}

	/**
	 * 
	 * A method that applies background linking using the terms extracted from TF or
	 * TF-IDF
	 * 
	 * @param lindex
	 * @param queryInfo
	 * @param queryDir
	 * @param Outdirectory
	 * @param outputfile
	 * @param loggerfile
	 * @param TFWords
	 * @param idf          -- wether or not to include idf
	 */
	public static void processQueriesTFIDF(String lindex, String queryInfo, String queryDir, String Outdirectory,
			String outputfile, String loggerfile, int TFWords, boolean idf) {
		try {
			int errorInQueries = 0;
			luceneIndex index = new luceneIndex(lindex);
			PrintWriter writer = new PrintWriter(Outdirectory + "/" + outputfile, "UTF-8");
			PrintWriter writerQuery = new PrintWriter(Outdirectory + "/query_" + outputfile, "UTF-8");

			PrintWriter writerLogger = new PrintWriter(Outdirectory + "/" + loggerfile, "UTF-8");

			/**
			 * loading stop words list
			 */
			ArrayList<String> stopwords = new ArrayList<String>();
			FileReader fileReader = new FileReader("StopWordsSEO.txt");

			BufferedReader bufferedReader = new BufferedReader(fileReader);

			String lineInput = bufferedReader.readLine();
			while (lineInput != null) {
				stopwords.add(lineInput.trim());
				lineInput = bufferedReader.readLine();
			}
			bufferedReader.close();

			/**
			 * loading ids of documents to correct missing dates in collection file
			 */
			HashMap<String, Long> idDates = new HashMap<String, Long>();
			try {
				fileReader = new FileReader("DocIdsDates.txt");

				bufferedReader = new BufferedReader(fileReader);

				String line = bufferedReader.readLine();

				while (line != null) {
					String[] str = line.split(",");
					idDates.put(str[0], Long.parseLong(str[1]));
					line = bufferedReader.readLine();
				}

			} catch (Exception te) {
				te.printStackTrace();
			}

			fileReader = new FileReader(queryInfo);
			bufferedReader = new BufferedReader(fileReader);

			String line = bufferedReader.readLine();

			Long TotalTime = 0l;
			int qcount = 0;
			long totalextractiontime = 0l;
			while (line != null) {
				String[] str = line.split("#");
				String topicNo = str[0];
				Long qDate = Long.parseLong(str[1]);
				String qTitle = str[2];
				String searchQuery = getQueryBody(queryDir + "/" + topicNo + ".txt");

				searchQuery = preProcessStringStopWordsRemoved(searchQuery, true, true, stopwords, false, 2);
				long starttimeE = System.currentTimeMillis();
				searchQuery = getTermsTFIDF(searchQuery, idf, TFWords, lindex);
				totalextractiontime = totalextractiontime + (System.currentTimeMillis() - starttimeE);

				qTitle = preProcessStringStopWordsRemoved(qTitle, true, false, stopwords, false, 0);

				//
				ArrayList<String> DocSignatures = new ArrayList<String>();
				DocSignatures.add(qTitle);

				writerQuery.println(searchQuery);
				qcount = qcount + 1;
				long starttime = System.currentTimeMillis();

				ScoreDoc[] hits = index.searchBody(searchQuery.trim());

				Long endtime = System.currentTimeMillis();
				Long Result = (endtime - starttime);
				TotalTime = TotalTime + Result;
				writerLogger.println(topicNo + " " + Result);
				IndexReader reader = DirectoryReader.open(index.iIndex);
				IndexSearcher searcher = new IndexSearcher(reader);

				int count = 0;
				// Now checking every hit to see if it can be added to our result set:
				for (int i = 0; i < hits.length; i++) {
					int docId = hits[i].doc;
					Document d = searcher.doc(docId);
					String docid = d.get("docID");
					Long docDate = (long) 0;
					try {
						docDate = idDates.get(docid);
					} catch (Exception e) {
						e.printStackTrace();
					}
					String field = d.get("field");
					String type = d.get("type");
					long datedifference = 0;
					if (docDate != null)
						datedifference = qDate - docDate;

					if (field.equals("Opinion") || field.equals("Editor") || field.equals("PostView"))
						continue;
					if (type.equals("Opinion") || type.equals("Editor") || type.equals("PostView"))
						continue;
					String signature = preProcessStringStopWordsRemoved(d.get("title"), true, false, stopwords, false,
							0);

					if (!DocSignatures.contains(signature)) // only if this document was not added before
						if (datedifference > 0 && (docDate != null) && (docDate != 0)) // only if the retrieved article
																						// is published before the
																						// current article, it can be
																						// added to the result
						{
							count = count + 1;

							writer.println(topicNo + " Q0 " + docid + " 0 " + hits[i].score + " QU_KTR");
							if (count == 100)
								break;
						}

				}
				if (count < 100) {
					// System.out.println("error in Topic"+topicNo);
					errorInQueries = errorInQueries + 1;
				}

				line = bufferedReader.readLine();
			}
			System.out.println("TF Extraction Time " + totalextractiontime + " " + idf);

			writer.close();
			writerLogger.close();
			writerQuery.close();
		} catch (Exception te) {
			te.printStackTrace();
		}
	}
}
