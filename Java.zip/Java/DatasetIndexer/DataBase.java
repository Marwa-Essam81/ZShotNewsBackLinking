package DatasetIndexer;

import java.io.BufferedReader;
import java.io.FileReader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document.OutputSettings;
import org.jsoup.nodes.Entities.EscapeMode;
import org.jsoup.parser.Parser;
import org.jsoup.safety.Whitelist;

public class DataBase {

	public static void main(String[] args) {
		createWBDatabase();

	}

	/* The following method creates a sql database that stores each article as a set of paragraph records after removing the html tags
	 */
	public static void createWBDatabase()
	{
		int fileno=14;
		try{
			Class.forName("com.mysql.jdbc.Driver");  
			
			
			
	    int count=0;
	    int indexed=0;
	    while(fileno<15)
	    {
	    	
	    	FileReader fileReader = new FileReader("V3CollectionFiles/TREC_WashingtonFile_"+fileno);
			

			BufferedReader bufferedReader = new BufferedReader(fileReader);
	        
		    String line=bufferedReader.readLine();
		    Connection con=DriverManager.getConnection(  
					"jdbc:mysql://localhost:3306/WPostDB","root","123456789");  
	    
		while(line!=null)
	    {
			
	    	String docid="";
	    	String pStmt="";
	    	try{
	    	count=count+1;
	    	if(count%1000==0) System.out.println(count);
	    	
	    	/***
	    	 * First Step Extract the kicker type
	    	 */
	    	String type="Normal";
	    	/**
	    	 * Extract the other data
	    	 */
	    	
	    	JSONObject	obj = (JSONObject) new JSONParser().parse(line);
	    	
	    	docid=(String)obj.get("id");
	    	
        	String title="T";
			try{ title=(String)obj.get("title");} catch(Exception te)  { }//te.printStackTrace();}
			if(title==null) { title="T";}
			String url="U";
			try{  url=(String)obj.get("article_url");} catch(Exception te)  { }//te.printStackTrace();}
			if(url==null) url="U";
			String author="A";
			try{  author=(String)obj.get("author");} catch(Exception te)  { }//te.printStackTrace();}
			if(author==null) author="A";
			long date=0;
			try{date=(Long)obj.get("published_date");} catch(Exception te) { }//te.printStackTrace();}
			
	        JSONArray contents=(JSONArray) obj.get("contents");
          
            /**
             * Round 1 ... get the title and date correctly
             */
            for(int i=0;i<contents.size();i++)
        	{
            	try {
            		JSONObject jobj=(JSONObject)contents.get(i);
            		String ctype="";
            		try{	ctype=(String)jobj.get("type");}catch(Exception te)  {}
    		
            				if(ctype.equals("title"))
            					if(title==null)
            					{
            						try{title=(String)jobj.get("content");
            						System.out.println(title);} catch(Exception te)  {}
            					}
            		else
            		if(date==0)
            			if(ctype.equals("date")) try{ date=(Long)obj.get("content");} catch(Exception te)  {}
            		else
                		if(ctype.equals("kicker"))
                		{
                			try{
                				type=(String)jobj.get("content");
                			}
                			catch(Exception te)  {}
                		}
    				}
            	
            	
            	
            	catch(Exception e)
            	{
            		System.out.print("error within document loop");
            		e.printStackTrace();
            		//not a type we are interested in
            	}
        	}
            /**
             * Saving the record of the document
             */
            pStmt="insert into Documents values ('"
            		+docid+
            		"','"
            		+ title.replace("'","\\'")
            		+ "','"+
            		type.replace("'","\\'")
            		+"','"+
            		url.replace("'","\\'")
            		+"','"+
            		author.replace("'","\\'")
            		+"',"+
            		Long.toString(date)+")";
            PreparedStatement preparedStmt = con.prepareStatement(pStmt);

		      preparedStmt.execute();
		      
		    /**
		     * Round 2: Saving the contents of paragraphs
		     */
		      int paragraphPos=1;
		      for(int i=0;i<contents.size();i++)
	        	{
	            	try {
	            		JSONObject jobj=(JSONObject)contents.get(i);
	            		String ctype=(String)jobj.get("type");
	            		if(ctype.equals("sanitized_html"))
	            		{
	            			String subtype=ctype=(String)jobj.get("subtype");
	            			
	            			if(subtype!=null&& subtype.equals("paragraph"))	            				
	            			{
	            				String content=(String)jobj.get("content");
	            				OutputSettings settings = new OutputSettings();
	            				settings.escapeMode(EscapeMode.base);
	            				String cleanHtml = Jsoup.clean(content, " ", Whitelist.none(), settings);
	            				cleanHtml=Parser.unescapeEntities(cleanHtml, false).replace("\\","\\\\").replace("'","\\'").replace("_","\\_").replace("%","\\%").replace("\"","\\'");
	            				if(!cleanHtml.replace(" ","").contentEquals(""))
	            				{
	            					String pid=""+docid+"_"+paragraphPos;
	            				
	            					preparedStmt = con.prepareStatement("insert into Contents values ('"
	            							+pid+
	            							"','"
	            							+docid+
	            		            		"','"
	            		            		+ cleanHtml
	            		            		+"',"+
	            		            		Integer.toString(paragraphPos)+")");
	            					paragraphPos=paragraphPos+1;
	            					preparedStmt.execute();
	            				} 
	            			}
	            		}
	            	}
	            	catch(NullPointerException e)
	            	{
	            	
	            	}
	            	catch(Exception e)
	            	{
	            		System.out.println("error in processing paragraphs of document:"+docid);
	            		System.out.println(preparedStmt);	            	}
	        	}  
	    	}
			catch(Exception e)
			{
				System.out.println("error adding document:"+docid);				e.printStackTrace();
			} 
	    	
	    	line=bufferedReader.readLine(); 
	    }
	    bufferedReader.close();
	    con.close();
	    fileno=fileno+1;
	    }
		}
		catch(Exception e)
		{
    		System.out.print("error ");
			e.printStackTrace();
		}
		
	}

}
